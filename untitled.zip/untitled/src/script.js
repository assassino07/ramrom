let role = "employee";
let empTasks = [
  { t: "Complete assembly MIG Welding Unit 320A", p: "high", done: false },
  {
    t: "Resolve cable shortage on Portable Welding Kit",
    p: "high",
    done: false
  },
  { t: "Prepare CNC Plasma Table for QC approval", p: "med", done: false },
  { t: "Send feedback request to EduLab Algeria", p: "low", done: true }
];
let mgrTasks = [
  { t: "Review Q2 production targets with team leads", p: "high", done: false },
  { t: "Approve budget for Ténès unit expansion", p: "high", done: false },
  { t: "Follow up on Sonatrach contract renewal", p: "med", done: false },
  { t: "Evaluate supplier for cooling fan modules", p: "med", done: true }
];
function selectRole(r) {
  role = r;
  document.querySelectorAll(".rc").forEach((el) => el.classList.remove("sel"));
  document.getElementById("rc-" + r.slice(0, 3)).classList.add("sel");
}
function doLogin() {
  const e = document.getElementById("lemail").value.trim();
  const p = document.getElementById("lpass").value;
  const err = document.getElementById("lerr");
  const valid =
    (role === "employee" && e === "employee@2mp.dz" && p === "1234") ||
    (role === "manager" && e === "manager@2mp.dz" && p === "1234");
  if (!valid) {
    err.style.display = "block";
    return;
  }
  err.style.display = "none";
  document.getElementById("LP").classList.add("dn");
  document.getElementById("DB").style.display = "block";
  document.getElementById("userAv").textContent =
    role === "employee" ? "E" : "M";
  document.getElementById("userName").textContent =
    role === "employee" ? "Ahmed Benali" : "Bilel Moussaoui";
  document.getElementById("userEmail").textContent = e;
  document.getElementById("userRole").textContent =
    role === "employee" ? "Employee" : "Manager";
  showPage("overview");
}
function doLogout() {
  document.getElementById("DB").style.display = "none";
  document.getElementById("LP").classList.remove("dn");
  document.getElementById("lemail").value = "";
  document.getElementById("lpass").value = "";
}
function closeModal() {
  document.getElementById("modalBg").classList.add("dn");
}
function openModal(t, b) {
  document.getElementById("modalTitle").textContent = t;
  document.getElementById("modalBody").textContent = b;
  document.getElementById("modalBg").classList.remove("dn");
}
function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2800);
}
function showPage(p) {
  document.querySelectorAll(".ni").forEach((n) => n.classList.remove("act"));
  event && event.target && event.target.classList.add("act");
  const ma = document.getElementById("mainArea");
  if (role === "employee") ma.innerHTML = getEmpPage(p);
  else ma.innerHTML = getMgrPage(p);
  bindTaskEvents();
}
function taskHtml(tasks, role) {
  return tasks
    .map(
      (t, i) =>
        `<div class='task-item${
          t.done ? " done" : ""
        }' data-i='${i}' data-role='${role}'><input type='checkbox'${
          t.done ? " checked" : ""
        }><span class='task-text'>${t.t}</span><span class='task-priority tp-${
          t.p === "high" ? "high" : t.p === "med" ? "med" : "low"
        }'>${
          t.p === "high" ? "High" : t.p === "med" ? "Medium" : "Low"
        }</span><button class='tdel'>&#10005;</button></div>`
    )
    .join("");
}
function bindTaskEvents() {
  document.querySelectorAll(".task-item").forEach((el) => {
    el.querySelector("input[type=checkbox]").onchange = function () {
      const i = +el.dataset.i,
        r = el.dataset.role;
      if (r === "employee") empTasks[i].done = this.checked;
      else mgrTasks[i].done = this.checked;
      el.classList.toggle("done", this.checked);
      toast(this.checked ? "Task marked done!" : "Task reopened");
    };
    el.querySelector(".tdel").onclick = function () {
      const i = +el.dataset.i,
        r = el.dataset.role;
      if (r === "employee") empTasks.splice(i, 1);
      else mgrTasks.splice(i, 1);
      showPage("tasks");
      toast("Task deleted");
    };
  });
  const btn = document.getElementById("addTaskBtn");
  if (btn)
    btn.onclick = function () {
      const inp = document.getElementById("taskInp"),
        sel = document.getElementById("taskPri");
      const txt = inp.value.trim();
      if (!txt) return;
      const t = { t: txt, p: sel.value, done: false };
      if (role === "employee") empTasks.unshift(t);
      else mgrTasks.unshift(t);
      inp.value = "";
      showPage("tasks");
      toast("Task added!");
    };
}
function getEmpPage(p) {
  const tasksSection = `<div class='card tm mb'><div class='sh'><h3>&#9989; My Tasks</h3><span class='sub'>${
    empTasks.filter((t) => !t.done).length
  } pending</span></div><div class='tadd'><input id='taskInp' placeholder='Add a new task...' /><select id='taskPri'><option value='high'>High</option><option value='med' selected>Medium</option><option value='low'>Low</option></select><button id='addTaskBtn'>+ Add</button></div>${taskHtml(
    empTasks,
    "employee"
  )}</div>`;
  if (p === "tasks")
    return `<div class='topbar'><div><h2>My Tasks</h2><p class='sub'>Personal task list for production and follow-up actions.</p></div><div class='cpill'><div class='mini'>Company</div><strong>2MP Industry SPA</strong><span>Boufarik HQ &bull; T&eacute;n&egrave;s Factory</span></div></div>${tasksSection}`;
  if (p === "orders")
    return `<div class='topbar'><div><h2>My Orders</h2><p class='sub'>Active production orders assigned to you.</p></div><div class='cpill'><div class='mini'>Company</div><strong>2MP Industry SPA</strong><span>contact@2mp-industry.com</span></div></div><div class='card mb'><div class='sh'><h3>Active Orders</h3><span class='sub'>Click any row for details</span></div><div class='tw'><table><thead><tr><th>Order ID</th><th>Client</th><th>Product</th><th>Qty</th><th>Status</th><th>Priority</th><th>Due</th></tr></thead><tbody><tr onclick="openModal('ORD-2048','Client: Sonatrach Industrial Services | Product: MIG Welding Unit 320A | Qty: 18 | Status: In Production | Due: 2026-11-12')"><td>ORD-2048</td><td>Sonatrach</td><td>MIG Welding Unit 320A</td><td>18</td><td><span class='bx b-blue'>In Production</span></td><td><span class='bx b-red'>High</span></td><td>2026-11-12</td></tr><tr onclick="openModal('ORD-2051','Client: MetalPro Chlef | Product: CNC Plasma Table | Qty: 2 | Status: Pending | Due: 2026-11-18')"><td>ORD-2051</td><td>MetalPro Chlef</td><td>CNC Plasma Table</td><td>2</td><td><span class='bx b-yellow'>Pending</span></td><td><span class='bx b-yellow'>Medium</span></td><td>2026-11-18</td></tr><tr onclick="openModal('ORD-2055','Client: EduLab Algeria | Product: Industrial 3D Printer | Qty: 4 | Status: Delivered | Due: 2026-09-28')"><td>ORD-2055</td><td>EduLab Algeria</td><td>Industrial 3D Printer</td><td>4</td><td><span class='bx b-green'>Delivered</span></td><td><span class='bx b-green'>Low</span></td><td>2026-09-28</td></tr><tr onclick="openModal('ORD-2059','Client: TechFab Oran | Product: Portable Welding Kit | Qty: 25 | Status: DELAYED - cable shortage | Due: 2026-10-03')"><td>ORD-2059</td><td>TechFab Oran</td><td>Portable Welding Kit</td><td>25</td><td><span class='bx b-orange'>Delayed</span></td><td><span class='bx b-red'>High</span></td><td>2026-10-03</td></tr></tbody></table></div></div>${tasksSection}`;
  if (p === "production")
    return `<div class='topbar'><div><h2>Production Board</h2><p class='sub'>Kanban view of active production stages.</p></div><div class='cpill'><div class='mini'>Site</div><strong>T&eacute;n&egrave;s Factory</strong><span>Wilaya de Chlef, Algeria</span></div></div><div class='card mb'><div class='sh'><h3>Kanban Board</h3><span class='sub'>Click any card for details</span></div><div class='board'><div class='lane'><div class='ltitle'>To Do <span class='lc'>3</span></div><div class='tc' onclick="openModal('CNC Plasma Table','Order ORD-2051 | Awaiting frame components and QC approval before launch.')"><strong>ORD-2051 &bull; CNC Plasma Table</strong><p>Awaiting frame components and QC approval.</p><small>Machines de d&eacute;coupe</small></div><div class='tc' onclick="openModal('Welding Accessories Pack','Order ORD-2060 | Batch scheduling planned for next week.')"><strong>ORD-2060 &bull; Welding Accessories Pack</strong><p>Batch scheduling planned for next week.</p><small>Postes &agrave; souder</small></div><div class='tc' onclick="openModal('Spare Parts Assembly','Materials available, assignment pending.')"><strong>ORD-2062 &bull; Spare Parts</strong><p>Materials available, assignment pending.</p><small>Service support</small></div></div><div class='lane'><div class='ltitle'>In Progress <span class='lc'>3</span></div><div class='tc' onclick="openModal('MIG Welding Unit 320A','Order ORD-2048 | 11/18 units completed. High priority for Sonatrach.')"><strong>ORD-2048 &bull; MIG Welding Unit 320A</strong><p>11/18 units completed. High priority.</p><small>Welding line</small></div><div class='tc' onclick="openModal('Portable Welding Kit - DELAYED','Order ORD-2059 | Delayed: power cable shortage. Escalated to purchasing.')"><strong>ORD-2059 &bull; Portable Welding Kit</strong><p>Delayed: cable shortage. Escalated.</p><small>Field maintenance</small></div><div class='tc' onclick="openModal('Control Panel Series','Testing phase underway before packaging.')"><strong>ORD-2061 &bull; Control Panel</strong><p>Testing phase underway before packaging.</p><small>Electrical components</small></div></div><div class='lane'><div class='ltitle'>Done <span class='lc'>2</span></div><div class='tc' onclick="openModal('Industrial 3D Printer - Delivered','Order ORD-2055 | Delivered to EduLab Algeria. Follow-up scheduled.')"><strong>ORD-2055 &bull; Industrial 3D Printer</strong><p>Delivered successfully. Follow-up scheduled.</p><small>3D printing solutions</small></div><div class='tc' onclick="openModal('Laser Accessory Module - Closed','Order ORD-2045 | Closed with full quality validation.')"><strong>ORD-2045 &bull; Laser Accessory Module</strong><p>Closed with full quality validation.</p><small>Laser cutting support</small></div></div></div></div>${tasksSection}`;
  if (p === "inventory")
    return `<div class='topbar'><div><h2>Inventory Alerts</h2><p class='sub'>Stock threshold monitoring for production components.</p></div><div class='cpill'><div class='mini'>Status</div><strong>2 Critical Items</strong><span>Action required immediately</span></div></div><div class='card mb'><div class='sh'><h3>Stock Levels</h3><span class='sub'>Click row for supplier details</span></div><div class='tw'><table><thead><tr><th>Material</th><th>Category</th><th>Qty</th><th>Threshold</th><th>Supplier</th><th>Status</th></tr></thead><tbody><tr onclick="openModal('Power Cable Set','Qty: 24 | Threshold: 40 | Supplier: Alger Tech Supply | Action: Reorder immediately - blocks ORD-2059')"><td>Power Cable Set</td><td>Component</td><td>24</td><td>40</td><td>Alger Tech Supply</td><td><span class='bx b-red'>Low Stock</span></td></tr><tr onclick="openModal('Cooling Fan Module','Qty: 19 | Threshold: 20 | Supplier: Electro Parts DZ | Action: Monitor closely')"><td>Cooling Fan Module</td><td>Component</td><td>19</td><td>20</td><td>Electro Parts DZ</td><td><span class='bx b-red'>Low Stock</span></td></tr><tr onclick="openModal('Control PCB Board','Qty: 34 | Threshold: 25 | Supplier: Oran Electronics | Status: Acceptable but watch')"><td>Control PCB Board</td><td>Component</td><td>34</td><td>25</td><td>Oran Electronics</td><td><span class='bx b-yellow'>Monitor</span></td></tr><tr onclick="openModal('Welding Transformer Core','Qty: 62 | Threshold: 30 | Supplier: Maghreb Steel | Status: OK')"><td>Welding Transformer Core</td><td>Raw Material</td><td>62</td><td>30</td><td>Maghreb Steel</td><td><span class='bx b-green'>OK</span></td></tr></tbody></table></div></div>${tasksSection}`;
  if (p === "crm")
    return `<div class='topbar'><div><h2>Customer Follow-up</h2><p class='sub'>CRM actions and client contact schedule.</p></div><div class='cpill'><div class='mini'>Actions</div><strong>4 Follow-ups Due</strong><span>This week</span></div></div><div class='card mb'><div class='sh'><h3>Client Actions</h3></div><div class='li'><div><strong>Sonatrach Industrial Services</strong><p>Energy sector &bull; 12 orders &bull; Call after delivery review of ORD-2048</p></div><span class='bx b-blue'>CRM</span></div><div class='li'><div><strong>MetalPro Chlef</strong><p>Manufacturing &bull; 7 orders &bull; Upsell CNC maintenance pack</p></div><span class='bx b-yellow'>Sales</span></div><div class='li'><div><strong>TechFab Oran</strong><p>Industrial Workshop &bull; 5 orders &bull; Quotation follow-up required</p></div><span class='bx b-orange'>Pending</span></div><div class='li'><div><strong>EduLab Algeria</strong><p>Training / Fablab &bull; 3 orders &bull; Request feedback 14 days post-delivery</p></div><span class='bx b-green'>Scheduled</span></div></div>${tasksSection}`;
  return `<div class='topbar'><div><h2>Employee Dashboard</h2><p class='sub'>Welcome. Your daily workspace for 2MP Industry SPA operations, production, stock and customer follow-up.</p></div><div class='cpill'><div class='mini'>Company</div><strong>2MP Industry SPA</strong><span>Founded 2010 &bull; Boufarik, Blida</span><span>contact@2mp-industry.com</span></div></div><div class='kg'><div class='card kpi'><div class='lb'>Assigned Orders</div><div class='vl'>9</div><div class='dl bl'>Active production load</div></div><div class='card kpi'><div class='lb'>Delayed Tasks</div><div class='vl'>3</div><div class='dl rd'>Action required</div></div><div class='card kpi'><div class='lb'>Low Stock Items</div><div class='vl'>4</div><div class='dl og'>2 critical items</div></div><div class='card kpi'><div class='lb'>My Tasks Pending</div><div class='vl'>${
    empTasks.filter((t) => !t.done).length
  }</div><div class='dl og'>Check tasks page</div></div></div>${tasksSection}<div class='g2'><div class='card'><div class='sh'><h3>Today Priorities</h3></div><div class='li'><div><strong>Complete MIG Welding Unit 320A</strong><p>11/18 done. High priority for Sonatrach order ORD-2048.</p></div><span class='bx b-red'>Urgent</span></div><div class='li'><div><strong>Resolve cable shortage ORD-2059</strong><p>Escalate to purchasing for Portable Welding Kit delay.</p></div><span class='bx b-orange'>Risk</span></div><div class='li'><div><strong>Approve CNC Plasma Table launch</strong><p>Frame components arrived. Waiting QC sign-off.</p></div><span class='bx b-yellow'>Waiting</span></div><div class='li'><div><strong>Send feedback to EduLab Algeria</strong><p>3D Printer delivered. Request post-delivery feedback.</p></div><span class='bx b-blue'>Follow-up</span></div></div><div class='card'><div class='sh'><h3>Company Info</h3></div><div class='li'><div><strong>Headquarters</strong><p>Lot N&deg;39, Zone Industrielle Boufarik Nord, Blida</p></div></div><div class='li'><div><strong>Production Unit</strong><p>Village Si ELWalid, BP 02081, T&eacute;n&egrave;s, Chlef</p></div></div><div class='li'><div><strong>Phone</strong><p>+213 25 28 39 90 &bull; +213 661 570 039</p></div></div><div class='li'><div><strong>Email</strong><p>contact@2mp-industry.com</p></div></div><div class='li'><div><strong>Warranty</strong><p>12-month warranty + after-sales service on all products</p></div></div></div></div>`;
}
function getMgrPage(p) {
  const tasksSection = `<div class='card tm mb'><div class='sh'><h3>&#128203; Manager Tasks</h3><span class='sub'>${
    mgrTasks.filter((t) => !t.done).length
  } pending</span></div><div class='tadd'><input id='taskInp' placeholder='Add a strategic task...' /><select id='taskPri'><option value='high'>High</option><option value='med' selected>Medium</option><option value='low'>Low</option></select><button id='addTaskBtn'>+ Add</button></div>${taskHtml(
    mgrTasks,
    "manager"
  )}</div>`;
  if (p === "tasks")
    return `<div class='topbar'><div><h2>Manager Tasks</h2><p class='sub'>Strategic task list for management decisions and follow-ups.</p></div><div class='cpill'><div class='mini'>Role</div><strong>Manager View</strong><span>2MP Industry SPA</span></div></div>${tasksSection}`;
  if (p === "orders")
    return `<div class='topbar'><div><h2>All Orders</h2><p class='sub'>Full order pipeline across all product families.</p></div><div class='cpill'><div class='mini'>Pipeline</div><strong>9 Active Orders</strong><span>3 delayed or at risk</span></div></div><div class='card mb'><div class='sh'><h3>Order Pipeline</h3></div><div class='tw'><table><thead><tr><th>Order</th><th>Client</th><th>Product Family</th><th>Value</th><th>Status</th><th>Risk</th></tr></thead><tbody><tr onclick="openModal('ORD-2048 - Sonatrach','18 x MIG Welding Unit 320A | Est. value: 3.2M DZD | On track for delivery Nov 12')"><td>ORD-2048</td><td>Sonatrach</td><td>Postes &agrave; souder</td><td>3.2M DZD</td><td><span class='bx b-blue'>In Production</span></td><td><span class='bx b-green'>Low</span></td></tr><tr onclick="openModal('ORD-2051 - MetalPro','2 x CNC Plasma Table | Est. value: 4.8M DZD | Awaiting QC approval')"><td>ORD-2051</td><td>MetalPro Chlef</td><td>Machines de d&eacute;coupe</td><td>4.8M DZD</td><td><span class='bx b-yellow'>Pending</span></td><td><span class='bx b-yellow'>Medium</span></td></tr><tr onclick="openModal('ORD-2059 - TechFab DELAYED','25 x Portable Welding Kit | Cable shortage blocking progress | Escalated')"><td>ORD-2059</td><td>TechFab Oran</td><td>Postes &agrave; souder</td><td>1.8M DZD</td><td><span class='bx b-orange'>Delayed</span></td><td><span class='bx b-red'>High</span></td></tr><tr onclick="openModal('ORD-2055 - EduLab','4 x Industrial 3D Printer | Delivered | Awaiting feedback')"><td>ORD-2055</td><td>EduLab Algeria</td><td>Imprimantes 3D</td><td>2.1M DZD</td><td><span class='bx b-green'>Delivered</span></td><td><span class='bx b-green'>None</span></td></tr></tbody></table></div></div>${tasksSection}`;
  if (p === "production")
    return `<div class='topbar'><div><h2>Production Overview</h2><p class='sub'>Cross-factory production status and bottleneck view.</p></div><div class='cpill'><div class='mini'>On-Time Rate</div><strong>88%</strong><span>+3% vs last month</span></div></div><div class='kg'><div class='card kpi'><div class='lb'>In Production</div><div class='vl'>6</div><div class='dl bl'>Active orders</div></div><div class='card kpi'><div class='lb'>Delayed</div><div class='vl'>2</div><div class='dl rd'>Needs escalation</div></div><div class='card kpi'><div class='lb'>Completed This Month</div><div class='vl'>11</div><div class='dl gn'>On track</div></div><div class='card kpi'><div class='lb'>Capacity Used</div><div class='vl'>74%</div><div class='dl og'>T&eacute;n&egrave;s factory</div></div></div><div class='card mb'><div class='sh'><h3>Bottlenecks</h3></div><div class='li'><div><strong>Power Cable Set shortage</strong><p>Blocking ORD-2059 completion. Reorder from Alger Tech Supply immediately.</p></div><span class='bx b-red'>Critical</span></div><div class='li'><div><strong>CNC QC approval pending</strong><p>ORD-2051 waiting on quality sign-off. Assign QC officer today.</p></div><span class='bx b-orange'>Action</span></div><div class='li'><div><strong>Cooling Fan Module near threshold</strong><p>19 units remaining vs threshold of 20. Order from Electro Parts DZ.</p></div><span class='bx b-yellow'>Watch</span></div></div>${tasksSection}`;
  if (p === "inventory")
    return `<div class='topbar'><div><h2>Inventory Management</h2><p class='sub'>Stock risk overview and supplier management.</p></div><div class='cpill'><div class='mini'>Risk</div><strong>2 Critical Items</strong><span>Supply chain action needed</span></div></div><div class='g3'><div class='card kpi'><div class='lb'>Total SKUs Tracked</div><div class='vl'>24</div><div class='dl bl'>Across all lines</div></div><div class='card kpi'><div class='lb'>Below Threshold</div><div class='vl'>4</div><div class='dl rd'>Reorder required</div></div><div class='card kpi'><div class='lb'>Avg Stock Cover</div><div class='vl'>18d</div><div class='dl og'>Days of production</div></div></div><div class='card mb'><div class='sh'><h3>Critical Stock</h3></div><div class='tw'><table><thead><tr><th>Item</th><th>Qty</th><th>Min</th><th>Impact</th><th>Supplier</th><th>Action</th></tr></thead><tbody><tr><td>Power Cable Set</td><td>24</td><td>40</td><td>Blocks ORD-2059</td><td>Alger Tech Supply</td><td><span class='bx b-red'>Reorder Now</span></td></tr><tr><td>Cooling Fan Module</td><td>19</td><td>20</td><td>Machine assembly</td><td>Electro Parts DZ</td><td><span class='bx b-red'>Reorder Now</span></td></tr><tr><td>Control PCB Board</td><td>34</td><td>25</td><td>Low risk</td><td>Oran Electronics</td><td><span class='bx b-yellow'>Monitor</span></td></tr><tr><td>Welding Transformer Core</td><td>62</td><td>30</td><td>No risk</td><td>Maghreb Steel</td><td><span class='bx b-green'>OK</span></td></tr></tbody></table></div></div>${tasksSection}`;
  if (p === "crm")
    return `<div class='topbar'><div><h2>Client Overview</h2><p class='sub'>Strategic CRM and sales pipeline for key accounts.</p></div><div class='cpill'><div class='mini'>Pipeline</div><strong>4 Key Accounts</strong><span>+21% forecast upside</span></div></div><div class='card mb'><div class='sh'><h3>Key Accounts</h3></div><div class='tw'><table><thead><tr><th>Client</th><th>Sector</th><th>Orders</th><th>Opportunity</th><th>Action</th></tr></thead><tbody><tr onclick="openModal('Sonatrach Industrial Services','Energy sector | 12 orders | Est. LTV: 18M DZD | Repeat welding equipment demand | Call after ORD-2048 delivery')"><td>Sonatrach Industrial Services</td><td>Energy</td><td>12</td><td>Repeat welding demand</td><td>Post-delivery call</td></tr><tr onclick="openModal('MetalPro Chlef','Manufacturing | 7 orders | CNC maintenance pack upsell opportunity worth ~2M DZD')"><td>MetalPro Chlef</td><td>Manufacturing</td><td>7</td><td>CNC maintenance pack</td><td>Upsell call</td></tr><tr onclick="openModal('TechFab Oran','Industrial Workshop | 5 orders | Quotation recovery needed for workshop expansion')"><td>TechFab Oran</td><td>Industrial</td><td>5</td><td>Quotation recovery</td><td>Commercial follow-up</td></tr><tr onclick="openModal('EduLab Algeria','Training/Fablab | 3 orders | 3D printing expansion for educational programs')"><td>EduLab Algeria</td><td>Education</td><td>3</td><td>3D printing expansion</td><td>Retention call</td></tr></tbody></table></div></div>${tasksSection}`;
  return `<div class='topbar'><div><h2>Manager Dashboard</h2><p class='sub'>Strategic overview of 2MP Industry SPA operations, product portfolio, CRM and risk management.</p></div><div class='cpill'><div class='mini'>Company</div><strong>2MP Industry SPA</strong><span>Founded 2010 &bull; 28 team members</span><span>Bilel &amp; Mohamed-Amine Moussaoui</span></div></div><div class='kg'><div class='card kpi'><div class='lb'>Orders In Production</div><div class='vl'>9</div><div class='dl bl'>Cross-factory load</div></div><div class='card kpi'><div class='lb'>On-Time Rate</div><div class='vl'>88%</div><div class='dl gn'>Stable rhythm</div></div><div class='card kpi'><div class='lb'>Stock Risks</div><div class='vl'>4</div><div class='dl rd'>2 critical items</div></div><div class='card kpi'><div class='lb'>Forecast Upside</div><div class='vl'>+21%</div><div class='dl gn'>Sales opportunity</div></div></div>${tasksSection}<div class='g3 mb'><div class='card'><div class='sh'><h3>Postes &agrave; Souder</h3></div><p style='color:#64748b;font-size:13.5px;line-height:1.6;margin-bottom:12px'>Core industrial line for professional workshops and field maintenance. Highest volume product family.</p><span class='bx b-blue'>Active Line</span></div><div class='card'><div class='sh'><h3>Machines de D&eacute;coupe</h3></div><p style='color:#64748b;font-size:13.5px;line-height:1.6;margin-bottom:12px'>CNC plasma and laser cutting for professionals. Growing order pipeline with MetalPro and TechFab.</p><span class='bx b-orange'>Growth Line</span></div><div class='card'><div class='sh'><h3>Imprimantes 3D</h3></div><p style='color:#64748b;font-size:13.5px;line-height:1.6;margin-bottom:12px'>Industrial 3D printers for prototyping and technical production. Strong in education sector.</p><span class='bx b-green'>Strategic Line</span></div></div><div class='g2'><div class='card'><div class='sh'><h3>Strategic Alerts</h3></div><div class='li'><div><strong>Power Cable shortage blocks ORD-2059</strong><p>TechFab delivery at risk. Escalate to supply chain today.</p></div><span class='bx b-red'>Critical</span></div><div class='li'><div><strong>Cooling Fan Module near zero</strong><p>19 units left vs threshold 20. Machine production at risk.</p></div><span class='bx b-orange'>Supply</span></div><div class='li'><div><strong>Sonatrach contract renewal due</strong><p>Largest client. Schedule strategic account review this quarter.</p></div><span class='bx b-blue'>CRM</span></div><div class='li'><div><strong>T&eacute;n&egrave;s capacity at 74%</strong><p>Plan ahead for Q4 demand increase across welding line.</p></div><span class='bx b-yellow'>Planning</span></div></div><div class='card'><div class='sh'><h3>2MP Company Profile</h3></div><div class='li'><div><strong>Founded</strong><p>2010 by Mohamed-Amine and Bilel Moussaoui, Algerian industrial entrepreneurs.</p></div></div><div class='li'><div><strong>Team</strong><p>28 employees including engineers, technicians and commercial advisors.</p></div></div><div class='li'><div><strong>Sites</strong><p>HQ in Boufarik (Blida) and production unit in T&eacute;n&egrave;s (Chlef).</p></div></div><div class='li'><div><strong>Service Promise</strong><p>12-month warranty, spare parts availability, after-sales support nationwide.</p></div></div></div></div>`;
}
document.addEventListener("keydown", function (e) {
  if (
    e.key === "Enter" &&
    document.getElementById("lpass") === document.activeElement
  )
    doLogin();
});
// Add download button to login page
const dlBtn = document.createElement("button");
dlBtn.textContent = "⬇ Download as HTML File";
dlBtn.style.cssText =
  "width:100%;padding:12px;margin-top:10px;border:2px solid #f97316;border-radius:14px;background:transparent;color:#f97316;font-size:14px;font-weight:700;cursor:pointer;";
dlBtn.onclick = function () {
  const src = document.documentElement.outerHTML;
  const blob = new Blob([src], { type: "text/html" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "2mp-smartops.html";
  a.click();
};
document.querySelector(".hint").after(dlBtn);
